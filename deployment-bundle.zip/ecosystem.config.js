module.exports = {
  apps: [
    {
      name: "devops-center",
      script: "./dist/server/uiServer.js",
      instances: 1,
      exec_mode: "fork",
      watch: false,
      max_memory_restart: "500M",
      env: {
        NODE_ENV: "production",
        UI_PORT: 4173
      },
      error_file: "./logs/pm2-error.log",
      out_file: "./logs/pm2-out.log",
      log_date_format: "YYYY-MM-DD HH:mm:ss Z",
      merge_logs: true,
      autorestart: true,
      wait_ready: true,
      listen_timeout: 3000,
      kill_timeout: 3000
    }
  ]
};
